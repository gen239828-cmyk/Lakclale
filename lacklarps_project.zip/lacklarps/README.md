# Lacklarps
A Vite + React app catalog with Supabase Auth, a public catalog, staff app management, and an owner user-role panel.


## 1. Install

Install Node.js (LTS), open this folder in a terminal, and run:

```bash
npm install
```

## 2. Add Supabase settings

Copy `.env.example` to `.env` and fill in:

- `VITE_SUPABASE_URL`: your Supabase project URL
- `VITE_SUPABASE_ANON_KEY`: your Supabase **publishable** key (safe for browser use when RLS is configured)

Never use a service-role key in a frontend environment file.


## 3. Configure database

In Supabase → SQL Editor, run `supabase-setup.sql`.

If the file reports a duplicate-policy error, make sure you copied the complete file and rerun; it drops its own policy names first. It is designed to be rerunnable.


## 4. Create your owner profile

1. Run the app and sign in with Google once, so a profile row is created.
2. In Supabase → SQL Editor, run the owner-bootstrap query from the bottom of `supabase-setup.sql`, replacing `OWNER_EMAIL` with your Google sign-in email.
3. Confirm that your profile role is `owner` in the `profiles` table. Do not publish your owner email in a public issue or screenshot.


## 5. Google OAuth

Supabase Auth → Providers → Google: enable Google and enter your OAuth Client ID and Client Secret.
In Google Cloud OAuth client settings, add this Authorized redirect URI:

`https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`

In Supabase Auth → URL Configuration, set Site URL to the deployed app origin, and add local/deployed origins to Redirect URLs, e.g.:
- `http://localhost:5173/**`
- `https://your-deployed-site.example/**`

Google OAuth client: use the app's website origin under Authorized JavaScript origins once deployed (and `http://localhost:5173` for local development). Do not put the Supabase API URL as the JavaScript origin unless it is the actual site origin.


## 6. Run locally

```bash
npm run dev
```
Open the local URL printed by Vite (usually `http://localhost:5173`).

## 7. Deploy

Build with:
```bash
npm run build
```
Upload the `dist` folder to a static hosting service (Vercel, Netlify, Cloudflare Pages, etc.) and set the same two environment variables in the hosting dashboard. Add the deployed site origin to Supabase Redirect URLs and Google OAuth Authorized JavaScript origins.


## Features
- Mobile responsive app catalog with search and category filters
- Google OAuth login via Supabase
- User profile view/sign out
- Staff (developer/owner) app CRUD dashboard
- Owner-only user listing and user/developer role changes
- Database RLS policies and protected role-management RPCs

## Notes
- Simulator app detail pages are currently placeholders, ready to be connected to individual experiences.
- This starter intentionally has no payment flow.
