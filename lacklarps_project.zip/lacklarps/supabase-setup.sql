-- Lacklarps Supabase setup. Safe to rerun.
-- 1) Run this whole file in Supabase SQL Editor.
-- 2) Replace OWNER_EMAIL below with the email you use to sign into Lacklarps.


create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text,
  role text not null default 'user' check (role in ('user','developer','owner')),
  created_at timestamptz not null default now()
);

create table if not exists public.apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  icon_url text,
  category text,
  is_featured boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.apps enable row level security;

-- Profile creation on signup; new users cannot choose their own role.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles (id,email,username,role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name'), 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Role lookup helper for policy decisions. This function is not callable to change roles.
create or replace function public.current_lacklarps_role()
returns text language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() limit 1 $$;
revoke all on function public.current_lacklarps_role() from public;
grant execute on function public.current_lacklarps_role() to authenticated;


-- RLS policies: remove old policy names first so this script can be rerun.
drop policy if exists "Users can view their own profile" on public.profiles;
drop policy if exists "Owners can view all profiles" on public.profiles;
drop policy if exists "Users can update their own profile" on public.profiles;
drop policy if exists "Owner can update profiles" on public.profiles;
drop policy if exists "Anyone can view apps" on public.apps;
drop policy if exists "Staff can insert apps" on public.apps;
drop policy if exists "Staff can update apps" on public.apps;
drop policy if exists "Staff can delete apps" on public.apps;

create policy "Users can view their own profile" on public.profiles
for select to authenticated using (auth.uid() = id);
create policy "Owners can view all profiles" on public.profiles
for select to authenticated using (public.current_lacklarps_role() = 'owner');
create policy "Anyone can view apps" on public.apps
for select to anon, authenticated using (true);


create policy "Staff can insert apps" on public.apps
for insert to authenticated with check (public.current_lacklarps_role() in ('owner','developer'));
create policy "Staff can update apps" on public.apps
for update to authenticated using (public.current_lacklarps_role() in ('owner','developer')) with check (public.current_lacklarps_role() in ('owner','developer'));
create policy "Staff can delete apps" on public.apps
for delete to authenticated using (public.current_lacklarps_role() in ('owner','developer'));

-- Owner-only profile listing RPC, restricted to the owner role.
create or replace function public.owner_list_profiles()
returns table (id uuid, email text, username text, role text, created_at timestamptz)
language plpgsql security definer set search_path=public
as $$
begin
  if public.current_lacklarps_role() <> 'owner' then
    raise exception 'Owner access required';
  end if;
  return query select p.id,p.email,p.username,p.role,p.created_at from public.profiles p order by p.created_at desc;
end;
$$;
revoke all on function public.owner_list_profiles() from public;
grant execute on function public.owner_list_profiles() to authenticated;

-- Owner may grant/revoke developer role. This function intentionally cannot create another owner.
create or replace function public.owner_set_role(target_user_id uuid, new_role text)
returns void language plpgsql security definer set search_path=public
as $$
begin
  if public.current_lacklarps_role() <> 'owner' then raise exception 'Owner access required'; end if;
  if new_role not in ('user','developer') then raise exception 'Role must be user or developer'; end if;
  update public.profiles set role=new_role where id=target_user_id;
  if not found then raise exception 'Profile not found'; end if;
end;
$$;
revoke all on function public.owner_set_role(uuid,text) from public;
grant execute on function public.owner_set_role(uuid,text) to authenticated;

-- BOOTSTRAP OWNER: replace the email, then run this block in the SQL editor.
-- Run it after your first Google sign-in so your auth user exists.
-- UPDATE public.profiles SET role='owner' WHERE lower(email)=lower('OWNER_EMAIL');
