import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key && !url.includes('YOUR_PROJECT') && !key.includes('YOUR_') ? createClient(url, key) : null;
const demoApps = [
  { name: 'Pocket Studio', category: 'Utilities', description: 'A clean sandbox for exploring mobile-style app experiences.', icon: '◈' },
  { name: 'Pixel Social', category: 'Social', description: 'Preview a fictional social feed and creator profile.', icon: '◎' },
  { name: 'Arcade Lab', category: 'Games', description: 'Explore mini-game concepts and arcade-inspired interfaces.', icon: '✦' },
  { name: 'Cloud Notes', category: 'Productivity', description: 'A lightweight note-taking demo with a simple interface.', icon: '▤' },
];
function App() {
  const [session, setSession] = useState(null);
  const [apps, setApps] = useState(demoApps);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [notice, setNotice] = useState('');
  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    supabase.from('apps').select('name,category,description,icon_url').then(({ data, error }) => {
      if (!error && data?.length) setApps(data.map(a => ({ ...a, icon: a.icon_url || '◈' })));
    });
    return () => listener.subscription.unsubscribe();
  }, []);
  async function signIn() {
    if (!supabase) { setNotice('Add your Supabase URL and publishable key in Vercel Environment Variables first.'); return; }
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } });
    if (error) setNotice(error.message);
  }
  async function signOut() { if (supabase) await supabase.auth.signOut(); }
  const cats = ['All', ...new Set(apps.map(a => a.category).filter(Boolean))];
  const filtered = apps.filter(a => (category === 'All' || a.category === category) && `${a.name} ${a.description || ''}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="app"><header><div className="brand"><span className="brandmark">L</span><span>LACKLARPS</span></div><div className="head-actions"><span className="catalog-label">APP CATALOG</span>{session ? <button className="button ghost" onClick={signOut}>Sign out</button> : <button className="button" onClick={signIn}>Sign in</button>}</div></header>
    <main><section className="hero"><p className="eyebrow">SIMULATOR LIBRARY</p><h1>Explore your next<br/><em>digital experience.</em></h1><p className="sub">A collection of app-inspired experiences. Browse, discover, and explore.</p><div className="searchbar"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search apps..." aria-label="Search apps"/></div></section>
    {notice && <div className="notice">{notice}</div>}<section className="catalog"><div className="section-title"><div><p className="eyebrow">THE LIBRARY</p><h2>Discover apps</h2></div><span className="count">{filtered.length} EXPERIENCES</span></div><div className="filters">{cats.map(c => <button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="grid">{filtered.map((a,i)=><article className="card" key={a.name}><div className="tile"><span>{a.icon || '◈'}</span><span className="tile-index">{String(i+1).padStart(2,'0')}</span></div><div className="card-meta"><span className="tag">{a.category || 'App'}</span><h3>{a.name}</h3><p>{a.description || 'Explore this simulator experience.'}</p><button className="launch" onClick={()=>setNotice(`${a.name} is a catalog preview. Simulator functionality can be added next.`)}>Explore <span>↗</span></button></div></article>)}</div>{filtered.length===0&&<p className="empty">No apps match that search.</p>}</section><footer><span>© {new Date().getFullYear()} LACKLARPS</span><span>SIMULATOR CATALOG</span></footer></main></div>
}
createRoot(document.getElementById('root')).render(<App/>);
