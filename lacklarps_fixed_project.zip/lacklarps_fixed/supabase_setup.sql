create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text,
  role text not null default 'user' check (role in ('user','developer','owner')),
  created_at timestamptz default now()
);
create table if not exists public.apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  icon_url text,
  category text,
  is_featured boolean default false,
  created_at timestamptz default now()
);
alter table public.profiles enable row level security;
alter table public.apps enable row level security;
drop policy if exists "Users can view their own profile" on public.profiles;
create policy "Users can view their own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Anyone can view apps" on public.apps;
create policy "Anyone can view apps" on public.apps for select to anon, authenticated using (true);
-- Keep profiles role changes restricted. Admin/developer write policies require trusted server-side authorization.
