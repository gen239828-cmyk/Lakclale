# Lacklarps (Vite + React + Supabase)

## Deploy on Vercel
1. Upload the **contents** of this folder to the root of your GitHub repository. `package.json` must be at the repository root.
2. Import the repo in Vercel. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
3. In Vercel Project Settings → Environment Variables add:
   - `VITE_SUPABASE_URL` = your Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY` = your Supabase publishable key (client-safe key)
4. Redeploy after adding env vars.

## Google login
Supabase → Authentication → URL Configuration: Site URL should be your deployed Vercel domain, and that domain should be in Additional Redirect URLs. Google OAuth Authorized redirect URI must be the Supabase callback URL shown in the Supabase Google provider setup.

## Notes
This is a catalog starter. App launchers are preview placeholders. The client does not include privileged role management; do not implement owner/developer grants in client-side code. Add server-side authorization and restrictive RLS policies before enabling role/admin actions.
